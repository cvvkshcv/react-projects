import logo from './logo.svg';
import './App.css';
import ShowName from './ShowName';
import { useState } from 'react';

function App() {
  
  const [name, setName] = useState('Vikash');

  const changeMyName = () => {
    console.log('Btn clicked');
    setName('Some other name');
  };

  return <div>
    <h1>{name}</h1>
    <button onClick={changeMyName}>Change name</button>
    <ShowName name={name} about={'Learning react'}/>
    <ShowName name={'Harpreet'} />
    <ShowName name={'Jhanvi'} about={'Learning Js'} />
    <ShowName name={'Preet'} about={'Learning HTML, CSS'} />
  </div>;
}

export default App;
